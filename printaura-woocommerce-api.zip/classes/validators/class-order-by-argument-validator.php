<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
class JSONAPI_OrderBy_Argument_Validator {
  public function validate( $source, &$value, &$result ) {

  }
}